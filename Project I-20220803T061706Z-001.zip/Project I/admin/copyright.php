<!-- copyright -->
<hr>
        <div class="container-fluid" align="center">
            <div class="row">
                <div class="col-md-12">
                    <i class="far fa-copyright">Sameer Maharjan & Surendra Kathariya</i>
                </div>
            </div>
        </div>


